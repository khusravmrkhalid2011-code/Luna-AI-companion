# Publish Luna (about 20 minutes, one time)

**Where the Ollama API key goes:** only in Vercel > your project > Settings > Environment Variables, named `OLLAMA_API_KEY`. Never put it in any file or in GitHub.

1. Firebase (free): console.firebase.google.com > Add project > Build > Authentication > Get started.
   - Sign-in method: enable **Google**.
   - Enable **GitHub**: create an OAuth app at github.com/settings/developers, paste its Client ID/Secret into Firebase, and put Firebase's callback URL into the GitHub app.
   - Project settings > Your apps > Web (</>) > copy the config values into `config.js`.
2. GitHub: create a repository and upload every file in this folder (`api/chat.js` included).
3. Vercel (free): vercel.com > Add New > Project > import that repository > before Deploy, add Environment Variables:
   - `OLLAMA_API_KEY` = your Ollama key (ollama.com/settings/keys)
   - `FIREBASE_API_KEY` = the same apiKey as in config.js
   - `ALLOWED_MODELS` = `gpt-oss:120b,gpt-oss:20b,qwen3-vl:235b` (must match the ids in config.js)
4. Deploy. Copy your `https://xxxx.vercel.app` address into Firebase > Authentication > Settings > Authorized domains.
5. Open the address on a phone in Chrome, sign in, then Chrome menu > Add to Home screen.
